player_speed = 3
movement_distance = 20
slow_turn_angle = 15