# Spaceship attempt
import turtle
screen = turtle.Screen()
screen.screensize(400,400)
screen.bgcolor("gray10")
bob = turtle.Turtle()
bob.penup()
bob.hideturtle()
bob.speed(0)

def redirect():
    bob.setheading(0)

def coordinate_stamp_y(intervals): #prints out y coordinates with yellow lines
    y_coord = -500
    bob.setheading(0)
    bob.pencolor("yellow")
    for x in range(intervals):
        bob.penup()
        bob.goto(-10, y_coord)
        bob.pendown()
        bob.forward(20)
        y_coord += 100
        bob.penup()



def coordinate_stamp_x(intervals): #prints out x coordinates with yellow lines
    x_coord = -500
    bob.setheading(90)
    bob.pencolor("yellow")
    for x in range(intervals):
        bob.penup()
        bob.goto(x_coord, -10)
        bob.pendown()
        bob.forward(20)
        x_coord += 100
        bob.penup()



def draw_oval(radius):
    bob.right(45)
    bob.begin_fill()
    bob.pendown()
    for _ in range(2):
        bob.circle(radius, 90)
        bob.circle(radius / 30, 90)
    bob.end_fill()
    bob.penup()



def draw_cylinder():
    bob.pencolor("gray30")
    bob.pensize(5)
    bob.fillcolor("gray20")
    bob.setheading(-90)
    bob.begin_fill()
    bob.pendown()
    bob.forward(200)
    bob.setheading(-45)
    bob.circle(100, 90)
    bob.left(90)
    bob.setheading(90)
    bob.forward(200)
    bob.left(90)
    bob.forward(140)
    bob.end_fill()
    bob.setheading(0)
    draw_oval(98)
    bob.penup()
    bob.setheading(-90)
    bob.forward(100)
    bob.setheading(0)
    bob.right(45)
    bob.begin_fill()
    bob.pendown()
    bob.circle(98, 90)
    bob.setheading(-90)
    bob.forward(30)
    bob.right(45)
    bob.circle(-98 , 90)
    bob.end_fill()
    bob.penup()
    bob.setheading(90)
    bob.forward(130)
    #bob.setheading(-40)
    bob.setheading(0)
    bob.forward(25)
    bob.setheading(90)
    bob.forward(20)
    bob.setheading(0)
    draw_oval(60)
    bob.setheading(-90)
    bob.forward(20)
    bob.setheading(180)
    bob.forward(30)
    bob.setheading(-40)




def draw_cylinder_row(count):
    for x in range(count):
        draw_cylinder()
        bob.forward(150)
        bob.setheading(-90)
        bob.forward(-70)
        bob.setheading(0)



def alt_oval(radius):
    bob.pencolor("coral4")
    bob.fillcolor("firebrick4")
    bob.pendown()
    bob.right(45)
    bob.begin_fill()
    for _ in range(2):
        bob.circle(radius, 90)
        bob.circle(radius / 30, 90)
    bob.end_fill()
    bob.penup()



def draw_alt_cyl():
    bob.setheading(-90)
    bob.pencolor("coral4")
    bob.fillcolor("firebrick4")
    bob.begin_fill()
    for x in range(4):
        bob.forward(100)
        bob.left(90)
    bob.setheading(0)
    bob.end_fill()
    alt_oval(69)
    bob.setheading(90)
    bob.forward(20)
    redirect()
    bob.forward(20)
    alt_oval(40)
    bob.setheading(180)
    bob.forward(20)
    bob.setheading(-90)
    bob.forward(20)
    bob.setheading(-45)




def draw_alt_cyl_row(count):
    for x in range(count):
        draw_alt_cyl()
        bob.forward(175)
        bob.setheading(-90)
        bob.forward(-95)
        bob.setheading(0)


def draw_shiphead():
    bob.pencolor("gray30")
    bob.fillcolor("gray20")
    bob.pensize(5)
    bob.pendown()
    bob.begin_fill()
    bob.setheading(-30)
    bob.circle(600, 30)
    bob.setheading(90)
    bob.circle(400, 60)
    bob.setheading(228)
    bob.circle(400, 42)
    bob.end_fill()
    bob.circle(400, -42)
    bob.setheading(-18)
    bob.begin_fill()
    bob.circle(-300, 84)
    bob.setheading(90)
    bob.circle(300, 40)
    bob.end_fill()
    bob.penup()

def draw_hull_subsection():
    bob.pencolor("gray30")
    bob.fillcolor("gray20")
    bob.pensize(5)
    bob.pendown()
    bob.begin_fill()
    bob.setheading(-90)
    bob.forward(200)
    bob.right(60)
    bob.forward(100)
    bob.setheading(90)
    bob.forward(200)
    bob.back(200)
    bob.setheading(160)
    bob.forward(150)
    bob.setheading(90)
    bob.forward(200)
    bob.end_fill()
    bob.penup()

def draw_main_hull():
    draw_hull_subsection()
    bob.back(70)
    bob.setheading(0)
    bob.forward(30)
    draw_hull_subsection()
    bob.setheading(-20)
    bob.pencolor("gray30")
    bob.fillcolor("gray20")
    bob.pendown()
    bob.begin_fill()
    bob.back(100)
    bob.forward(400)
    bob.setheading(86)
    bob.forward(300)
    bob.back(300)
    bob.setheading(20)
    bob.forward(200)
    bob.setheading(86)
    bob.forward(300)
    bob.setheading(200)
    bob.forward(200)
    bob.setheading(160)
    bob.forward(350) #erm
    bob.back(350)
    bob.setheading(200)
    bob.back(200)
    bob.setheading(160)
    bob.forward(350)
    bob.setheading(200)
    bob.forward(350)
    bob.setheading(-73)
    bob.forward(240)
    bob.end_fill()
    bob.penup()

def draw_thrusters():
    bob.pencolor("gray30")
    bob.fillcolor("gray20")
    bob.pensize(5)
    bob.pendown()
    bob.begin_fill()
    bob.setheading(-20)
    bob.forward(300)
    bob.circle(-100, 40)
    bob.circle(-50, 40)
    bob.circle(-300, 10)
    bob.circle(-100, 40)
    bob.circle(-50, 40)
    bob.setheading(-70)
    bob.circle(150, -75)
    bob.setheading(-70)
    bob.circle(-150, 75)
    bob.setheading(160)
    bob.forward(350)
    bob.setheading(155)
    bob.circle(-93, 180)
    bob.setheading(0)
    bob.end_fill()
    bob.penup()









bob.setheading(-90)
bob.forward(100)
draw_main_hull()
bob.home()
draw_cylinder_row(5)
bob.home()
draw_alt_cyl_row(4)
bob.goto(-75, -50)
bob.setheading(0)
draw_cylinder_row(5)
bob.setheading(-90)
bob.forward(200)
bob.setheading(0)
draw_shiphead()
bob.home()
bob.setheading(180)
bob.forward(550)
draw_thrusters()


screen.mainloop()